function validateCredentials()
{
	var uname= document.getElementById("txtEmail").value;
	var pass= document.getElementById("txtPass").value;
	
	$.get("credentials.json",
			
			function(data,status)
			{
				var users = JSON.parse(data);
				for(user of users)
					{
						if(user.user1==uname && user.password==pass)
							{
								$("#div1").load("TermsandCondition.html");
							
								
						
					
					}
		
			}
			
	
			}
	)
	

}